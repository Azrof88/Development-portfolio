package constants;

public class DatabaseConstants {
    public static final String CONNECTION_URL = "jdbc:sqlite:E:/Development-portfolio/Desktop/Quiz_application/quiz.db";
    public static final String DRIVER_CLASS = "org.sqlite.JDBC";
}
